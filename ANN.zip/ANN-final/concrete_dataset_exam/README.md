# Assignment Question

Using the provided UCI Concrete Compressive Strength dataset and the starter Python script in this folder, develop a regression model with sklearn, PyTorch, Keras, or TensorFlow.
Evaluate regression performance using metrics like R2 , MSE, RMSE, MAE. Discuss your results.

The dataset is already available locally as `concrete_data.csv`. The starter script `concrete_regression_solution.py` already reads the dataset from the same folder. Continue from that script and complete the regression workflow.

## UCI Concrete Compressive Strength Dataset Description

The UCI Concrete Compressive Strength dataset contains concrete mixture ingredients, curing age, and the measured compressive strength of concrete. It has 1030 rows and 9 columns.

The dataset is used for regression. The main prediction target is concrete compressive strength.

## Columns

### Dependent Variable / Target Column

- `concrete_compressive_strength`: concrete compressive strength in MPa.

### Independent Variables / Feature Columns

The dataset contains these independent variables:

- `cement`: cement amount in kg/m^3.
- `blast_furnace_slag`: blast furnace slag amount in kg/m^3.
- `fly_ash`: fly ash amount in kg/m^3.
- `water`: water amount in kg/m^3.
- `superplasticizer`: superplasticizer amount in kg/m^3.
- `coarse_aggregate`: coarse aggregate amount in kg/m^3.
- `fine_aggregate`: fine aggregate amount in kg/m^3.
- `age`: curing age in days.

## Missing Values

The dataset does not contain missing values.

## Original Column Meaning

The original UCI file describes the variables as 8 quantitative input variables and 1 quantitative output variable:

- Cement, blast furnace slag, fly ash, water, superplasticizer, coarse aggregate, fine aggregate, and age are input variables.
- Concrete compressive strength is the output variable.
