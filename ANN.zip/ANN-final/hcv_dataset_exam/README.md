# Assignment Question

Using the provided UCI HCV dataset and the starter Python script in this folder, develop a classification model with sklearn, PyTorch, Keras, or TensorFlow. Evaluate classification
performance using metrics like accuracy, sensitivity, spesificity and F1 Score.

The dataset is already available locally as `hcvdat0.csv`. The starter script `hcv_classification_solution.py` already reads the dataset from the same folder. Continue from that script and complete the classification workflow.

# UCI HCV Dataset Description

The UCI HCV dataset contains laboratory blood values and demographic information for blood donors and Hepatitis C patients. It has 615 rows and 14 columns in the CSV file.

The dataset can be used for classification. The main prediction target is the patient's diagnosis category.

## Columns

### Dependent Variable / Target Column

- `Category`: diagnosis label.

Original target classes:

- `0=Blood Donor`: normal blood donor.
- `0s=suspect Blood Donor`: suspect blood donor.
- `1=Hepatitis`: Hepatitis C.
- `2=Fibrosis`: fibrosis stage.
- `3=Cirrhosis`: cirrhosis stage.

### Independent Variables / Feature Columns

The dataset contains these independent variables:

- `Age`: age in years.
- `Sex`: sex, represented as `m` or `f`.
- `ALB`: albumin laboratory value.
- `ALP`: alkaline phosphatase laboratory value.
- `ALT`: alanine aminotransferase laboratory value.
- `AST`: aspartate aminotransferase laboratory value.
- `BIL`: bilirubin laboratory value.
- `CHE`: cholinesterase laboratory value.
- `CHOL`: cholesterol laboratory value.
- `CREA`: creatinine laboratory value.
- `GGT`: gamma-glutamyl transferase laboratory value.
- `PROT`: protein laboratory value.

The CSV also contains `Unnamed: 0`, which is only a row/patient identifier. It is not used as a model feature.

## Missing Values

Some feature columns contain missing values:

- `ALB`: 1 missing value.
- `ALP`: 18 missing values.
- `ALT`: 1 missing value.
- `CHOL`: 10 missing values.
- `PROT`: 1 missing value.
